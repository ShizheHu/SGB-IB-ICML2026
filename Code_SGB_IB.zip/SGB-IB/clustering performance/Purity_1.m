function [p,dist]=Purity_1(indCluster,classes)
% compute purity of clustering according to class information
% indCluster: column vector, the cluster index of each data point
% classes: column vector, the class label of each data point
% p: scalar, purity
% dist: the distribution matrix of clustering

%%%%

numSample=numel(classes);
uniClass=unique(classes);
numClass=numel(uniClass);
uniCluster=unique(indCluster);
numCluster=numel(uniCluster);
dist=zeros(numCluster,numClass);
for i=1:numCluster
    curClu=(indCluster==(uniCluster(i)));
    for j=1:numClass
        curCla=(classes==uniClass(j));
        dist(i,j)=sum(curClu&curCla);
    end
end
p=sum(max(dist,[],2))/numSample;
end

