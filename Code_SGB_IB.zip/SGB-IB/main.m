clear; clc; close all;
addpath('Mainfunction', 'clustering performance');
path1 = 'Mainfunction';
path2 = 'clustering performance';
addpath(path1);
addpath(path2);

path = '../data_BBC4view5cluster/';
m = 4;  % Number of modalities
Tsize = 5; % Number of clusters
UniformPrior = 1;
min_samples = 20; % Fixed parameter
purity_threshold = 0.6; % Fixed parameter
alpha = 0;  
beta = 500;  
restart = 30; 
cellX = cell(m, 1);
gnd = [];
for i = 1:m
    task_data = load([path 'view' num2str(i)]);
    A = task_data.fea;
    if isempty(gnd), gnd = task_data.gnd; end 
    A = full(A);
    A(:, find(sum(abs(A), 1) == 0)) = [];
    cellX{i} = A;
end
all_AC = zeros(restart, 1);
all_NMI = zeros(restart, 1);
all_purity = zeros(restart, 1);

for run = 1:restart
    view_pseudo_labels = cell(m, 1);
    for i = 1:m
        view_features = cellX{i};
        [pseudo_i, ~] = kmeans(view_features, Tsize, ...
            'Replicates', 10, 'Distance', 'cosine');
        view_pseudo_labels{i} = pseudo_i(:);
    end
    [granular_structure, ~, sample_to_granule] = recursive_split(cellX, view_pseudo_labels, ...
        purity_threshold, min_samples); 
    cellX_transformed = cell(m, 1);
    for vi = 1:m
        cellX_transformed{vi} = granular_structure.centers{vi};
    end
    [CR] = MIB(cellX_transformed, m, Tsize, UniformPrior,alpha, beta);
    sample_level_labels = CR(1, sample_to_granule);  
    all_AC(run) = averageAC(sample_level_labels, gnd);
    all_NMI(run) = func_nmi(gnd', sample_level_labels);
    all_purity(run) = Purity_1(sample_level_labels', gnd);
    fprintf ('restart number %d...\n',run);
end
mean_AC = mean(all_AC);
std_AC = std(all_AC);
mean_NMI = mean(all_NMI);
std_NMI = std(all_NMI);
mean_purity = mean(all_purity);
std_purity = std(all_purity);

fprintf('Mean ACC: %.4f ± %.4f\n', mean_AC, std_AC);
fprintf('Mean NMI: %.4f ± %.4f\n', mean_NMI, std_NMI);