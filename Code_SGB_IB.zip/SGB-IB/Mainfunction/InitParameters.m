function [prm] = InitParameters (Tsize,UniformPrior, beta)

% [prm.X prm.Y] = size(M);
prm.Tsize = Tsize;   
prm.UniformPrior = UniformPrior;
prm.beta = beta;
% Default values - change when necessary...
prm.LoopLimit = 80;  
prm.SmallChange = 0;
prm.CalcI = 0;  % Turn to 1 to record information values after each assignment update (at cost of speed!)
prm.run_index = datestr(now);
prm.RunSeed = 0; % use 'sum(100*clock)' for "random" seed

rand('state',prm.RunSeed);

return
