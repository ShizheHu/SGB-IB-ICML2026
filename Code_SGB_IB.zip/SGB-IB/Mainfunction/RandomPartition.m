function Pt_x = RandomPartition(Xsize,Tsize)

 % Produce a random partition as an initialization point
 Pt_x = zeros(1,Xsize);   
 perm = randperm(Xsize);
    AvgSize = Xsize/Tsize;
    i2 = 0;
    for t=1:Tsize
        i1 = i2+1;
        i2 = min(ceil(t*AvgSize),Xsize);
        inds = perm(i1:i2);
        Pt_x(inds) = t;
    end
    