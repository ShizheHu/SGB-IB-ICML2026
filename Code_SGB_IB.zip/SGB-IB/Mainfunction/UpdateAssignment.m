

function [T] = UpdateAssignment (T,new_t,tmpPt,tmpPy_t,tmpPx,tmpPy_x)        
	
% update membership

% update centroid p(y|t) by merging x to new_t	
T.Py_t = tmpPy_t;	
mass = tmpPx+T.Pt(new_t);	
pi1 = tmpPx/mass;	
pi2 = T.Pt(new_t)/mass;	
T.Py_t (:,new_t) = pi1*tmpPy_x+pi2*T.Py_t(:,new_t);
		
% update priors	
T.Pt = tmpPt;	
T.Pt(new_t) = mass;
