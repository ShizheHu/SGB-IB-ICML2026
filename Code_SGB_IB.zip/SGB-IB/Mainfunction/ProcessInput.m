function [cellInp] = ProcessInput (cellX,m,prm)

cellInp=cell(m,1);

for i=1:m
    if ((min(sum(cellX{i},1))<=0) | (min(sum(cellX{i},2))<=0))
        error ('zero priors in M - empty columns or rows are not allowed');
    end
    
    if prm.UniformPrior
        cellX{i} = NormMat(cellX{i});
    end
    
    cellInp{i}.Py_x = (NormMat(cellX{i}))';
    cellInp{i}.Pyx = cellX{i}'./sum(sum(cellX{i}));
    cellInp{i}.Px = sum(cellInp{i}.Pyx,1);
    cellInp{i}.Py = sum(cellInp{i}.Pyx,2);
    
    [cellInp{i}.I] = MI(cellInp{i}.Pyx);
end
return
