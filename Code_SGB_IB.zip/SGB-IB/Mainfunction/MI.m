
function [I] = MI(P)

if min(size(P))<2
  warning ('This is not a JOINT distribution');
  Hx = Ent(P);
  Hy = 0;
  I = 0;
end

if min(min(P)) < 0,
  error ('Negative probability values');
end;

if (abs(sum(sum(P))-1) >= 1e-6)
  fprintf ('sum_{x,y}P(x,y)=%f\n',full(sum(sum(P))));
  error ('Unnormalized joint distribution');
end;

Px=sum(P');
Hx=Ent(Px);
Py=sum(P);
Hy=Ent(Py);

inds = find(P);
I = Hx + Hy + sum(sum(P(inds).*MyLog(P(inds))));	

return
