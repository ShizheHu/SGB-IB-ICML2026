
function[CR] = MIB (cellX,m, Tsize, UniformPrior, alpha, beta)
format compact
% Init functions

[prm] = InitParameters (Tsize, UniformPrior, beta);
[cellInp] = ProcessInput (cellX, m, prm);
% Main loop 
Xsize = size(cellX{1},1);
CR = zeros(Xsize); 
view_sim = cell(m, 1);
for v = 1:m
    norm_centers_v = normalize(cellX{v}, 'norm', 2);
    view_sim{v} = norm_centers_v * norm_centers_v';  
end
cos_sim_matrix = mean(cat(3, view_sim{:}), 3);


k = 1;
Pt_x = RandomPartition(Xsize, Tsize);

DimY = zeros(m, 1);
for i = 1:m
    [X, DimY(i)] = size(cellX{i});
end 
[celltmpT] = InitT (Pt_x, cellInp, X, DimY, Tsize, m);

[Pt_x] = OptimizeT (X, Pt_x, cellInp, celltmpT, prm, m, cos_sim_matrix, alpha);

CR(k,:) = Pt_x;

return