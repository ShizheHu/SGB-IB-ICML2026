function [Costs] = MergeCosts(Py_x, Py_t, Px, Pt, prm, cos_sim_matrix, lambda, current_granule)
    K = prm.Tsize;
    Costs = zeros(1, K);
    g = current_granule;
    if prm.beta ~= 0
        inv_beta = 1 / prm.beta;  
    else
        inv_beta = 0;  
    end
    for t = 1:K
        Pnew = Px + Pt(t);
        pi1 = Px / Pnew; 
        pi2 = Pt(t) / Pnew;
        tmpJS = JS(Py_x, Py_t(:,t), pi1, pi2);
        info_loss = Pnew * tmpJS;
        Costs(t) = info_loss;
        if lambda ~= 0  
            granules_in_t = find(prm.Pt_x == t);
            n_granules = size(cos_sim_matrix, 1);
            all_sims = cos_sim_matrix(g, :);
            if ~isempty(granules_in_t)
                sim_to_t = mean(all_sims(granules_in_t));
                other_granules = setdiff(1:n_granules, [g, granules_in_t]);
                if ~isempty(other_granules)
                    sim_to_others = mean(all_sims(other_granules));
                    sim_ratio = sim_to_t / (sim_to_others);
                    struct_term = exp(-sim_ratio);
                    Costs(t) = Costs(t) * (1 - lambda * (1 - struct_term));
                end
            end
        end

        if inv_beta ~= 0
            compression_gain = Pnew * inv_beta * Ent([pi1 pi2]);
            Costs(t) = Costs(t) - compression_gain;
        end
    end
    if lambda == 0 && inv_beta == 0
        return;
    end
end
