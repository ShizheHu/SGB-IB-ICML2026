function [Pt_x]=OptimizeT(X, Pt_x, cellInp, celltmpT, prm, m, cos_sim_matrix, lambda)
   
    LoopCounter = 1;
    NoChange = 0;
    done = 0;
    cellTemp=cell(m,1);
    cellCosts=cell(m,1);

 
    prm.Pt_x = Pt_x;

    while ~done
        change = 0;
        for x = 1:X
            t = Pt_x(x);
            inds_t = logical(Pt_x==t);
            
            for i=1:m
                cellTemp{i}.Py_x = cellInp{i}.Py_x(:,x);
                cellTemp{i}.Px = cellInp{i}.Px(x);
                cellTemp{i}.Py_t = celltmpT{i}.Py_t;
                cellTemp{i}.Pt = celltmpT{i}.Pt;
            end
            
            if sum(inds_t) > 1, 
                for i=1:m
                    [tmpPt,tmpPy_t] = Reduce_x(cellTemp{i}.Pt, cellTemp{i}.Py_t, t, cellTemp{i}.Px, x, cellInp{i}.Pyx);
                    cellTemp{i}.Pt = tmpPt;
                    cellTemp{i}.Py_t = tmpPy_t;
                end
     
                temp_Pt_x = Pt_x;
                temp_Pt_x(x) = 0; 
                prm.Pt_x = temp_Pt_x;
                
                % Calc Merge costs
                for i=1:m
                    [CostsTemp] = MergeCosts(cellTemp{i}.Py_x, cellTemp{i}.Py_t, cellTemp{i}.Px, cellTemp{i}.Pt, prm, cos_sim_matrix, lambda, x);
                    cellCosts{i} = CostsTemp;
                end
                Costs = cellCosts{1};  
                for i=2:m
                    Costs = cellCosts{i} + Costs;  
                end
                [~,new_t] = min(Costs);
                
                % Merge x back
                if new_t == t
                    NoChange = NoChange+1;
                else
                    NoChange = 0;
                    change = change+1;
                    Pt_x(x) = new_t;
                    for i=1:m
                        [TTemp] = UpdateAssignment(celltmpT{i}, new_t, cellTemp{i}.Pt, cellTemp{i}.Py_t, cellTemp{i}.Px, cellTemp{i}.Py_x);
                        celltmpT{i} = TTemp;
                    end
                end % if new_t == t
        
                prm.Pt_x = Pt_x;
            end % 'if sum(inds_t) > 1'
        end  % loop on X
        
        [done] = CheckConvergence(prm, LoopCounter, change);
        LoopCounter = LoopCounter+1;
        
    end % main 'while' loop

    return
end