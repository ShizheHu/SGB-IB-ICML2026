function conM = confusionmatrix(indx,L,clusters,categories)

conM = zeros(categories,clusters);
u = unique(indx);
for i = 1:length(indx)
    r = find(L(i,:) ~= 0);
    c = find(u == indx(i));
    conM(r,c) = conM(r,c) + 1;
end