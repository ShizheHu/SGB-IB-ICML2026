
function [celltmpT] = InitT (Pt_x,cellInp,X,DimY,Tsize,m)

celltmpT=cell(m,1);

for i=1:m
    celltmpT{i}.size = Tsize;
    celltmpT{i}.costs = zeros(1,X);
    celltmpT{i}.Pt = zeros(1,Tsize);
    celltmpT{i}.Py_t = zeros(DimY(i),Tsize);
    celltmpT{i}.Pt_x=zeros(1,X);
    celltmpT{i}.Counter = 1;
    
    for t=1:Tsize
        inds = find(Pt_x == t);
        celltmpT{i}.Pt_x(inds) = t;
        celltmpT{i}.Pt(t) = sum(cellInp{i}.Px(inds));
        celltmpT{i}.Py_t(:,t) = sum(cellInp{i}.Pyx(:,inds),2)./celltmpT{i}.Pt(t);
    end
end

return
