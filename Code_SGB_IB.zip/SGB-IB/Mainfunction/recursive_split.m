function [granular, purity, sample_to_granule, low_count] = recursive_split(cellX, view_pseudo_labels, purity_threshold, min_samples)
    m = length(cellX);
    n = size(cellX{1}, 1);
    all_pure = true;
    for vi = 1:m
        if length(unique(view_pseudo_labels{vi})) > 1
            all_pure = false;
            break;
        end
    end
    if all_pure
        centers = cell(m, 1);
        for vi = 1:m
            centers{vi} = mean(cellX{vi}, 1);
        end
        granular = struct('centers', []);
        granular.centers = centers;
        sample_to_granule = ones(n, 1);
        purity = 1;  
        low_count = false;
        return;
    end
    current_purity = multiview_purity_weighted(cellX, view_pseudo_labels);
    if current_purity >= purity_threshold || n < min_samples
        centers = cell(m, 1);
        for vi = 1:m
            centers{vi} = mean(cellX{vi}, 1);
        end
        granular = struct('centers', []);
        granular.centers = centers;
        sample_to_granule = ones(n, 1);
        purity = current_purity;
        low_count = current_purity < purity_threshold;
        return;
    end
    combined_features = cat(2, cellX{:});
    [cluster_labels, ~] = kmeans(combined_features, 2, 'Replicates', 10, 'Distance', 'cosine');
    granular = struct('centers', []);
    granular.centers = cell(m, 1);
    for vi = 1:m
        granular.centers{vi} = zeros(0, size(cellX{vi}, 2));
    end
    sample_to_granule = [];
    low_count_total = 0;
    processed_samples = 0;
    for c = 1:2
        mask = cluster_labels == c;
        if sum(mask) == 0, continue; end  
        sub_cellX = cell(m, 1);
        sub_view_pseudo = cell(m, 1);
        for vi = 1:m
            sub_cellX{vi} = cellX{vi}(mask, :);
            sub_view_pseudo{vi} = view_pseudo_labels{vi}(mask);
        end
        processed_samples = processed_samples + sum(mask);
        [sub_granular, sub_purity, sub_mapping, sub_low] = recursive_split(sub_cellX, sub_view_pseudo, purity_threshold, min_samples);
        offset = size(granular.centers{1}, 1);
        for vi = 1:m
            granular.centers{vi} = [granular.centers{vi}; sub_granular.centers{vi}];
        end
        sample_to_granule(mask) = sub_mapping + offset;
    end
    if processed_samples == 0 || isempty(granular.centers{1})
        centers = cell(m, 1);
        for vi = 1:m
            centers{vi} = mean(cellX{vi}, 1);
        end
        granular = struct('centers', []);
        granular.centers = centers;
        sample_to_granule = ones(n, 1);
        purity = current_purity;
        low_count = current_purity < purity_threshold;
        return;
    end
    purity = 0;
    low_count = low_count_total;
end

function purity = multiview_purity_weighted(cellX, view_pseudo_labels)
    m = length(cellX);
    view_mi = zeros(m, 1);
    for vi = 1:m
        data = cellX{vi};
        pseudo_labels = view_pseudo_labels{vi};
        d = size(data, 2);
        valid_features = 0;
        feature_mi_sum = 0;
        for j = 1:d
            feature = data(:, j);
            if length(unique(feature)) <= 1
                continue;  
            end
            valid_features = valid_features + 1;
            mi_score = mutual_info(feature, pseudo_labels);
            feature_mi_sum = feature_mi_sum + mi_score;
        end
        if valid_features > 0
            view_mi(vi) = feature_mi_sum / valid_features;
        else
            view_mi(vi) = 0;  
        end
    end
    purity = sum(view_mi) / m;
    purity = max(0, min(1, purity));  
end

function nmi_score = mutual_info(feature, labels)
    n = length(feature);
    feature = feature(:);
    labels = labels(:);
    [f_unique, ~, f_idx] = unique(feature);
    [l_unique, ~, l_idx] = unique(labels);
    num_f = length(f_unique);
    num_l = length(l_unique);
    joint_counts = sparse(f_idx, l_idx, 1, num_f, num_l);
    joint_prob = joint_counts / n;  
    p_f = sum(joint_prob, 2);  
    p_l = sum(joint_prob, 1);  
    H_f = -sum(p_f(p_f>0) .* log2(p_f(p_f>0)));  
    H_l = -sum(p_l(p_l>0) .* log2(p_l(p_l>0)));  
    mi = 0;
    for i = 1:num_f
        for j = 1:num_l
            if joint_prob(i,j) > 0
                mi = mi + joint_prob(i,j) * log2(joint_prob(i,j) / (p_f(i) * p_l(j)));
            end
        end
    end
    if H_f + H_l > eps
        nmi_score = 2 * mi / (H_f + H_l);
    else
        nmi_score = 0;
    end
    nmi_score = max(0, min(1, nmi_score));
end