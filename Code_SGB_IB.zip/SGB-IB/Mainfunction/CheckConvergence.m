function [done] = CheckConvergence (prm,LoopCounter,change)
  
CHANGE=change;
LOOPCOUNTER = LoopCounter;
  
done = 0;  
 
if change <= prm.SmallChange     
    
    done = 1;    
elseif LoopCounter >= prm.LoopLimit

    done = 1;
end
  
return

  
