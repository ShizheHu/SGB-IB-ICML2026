function [logStr] = AddToLog(logStr, s)

logStr = strvcat(logStr, s);
