
function [tmpPt,tmpPy_t] = Reduce_x (tmpPt,tmpPy_t,t,tmpPx,x,Pyx)        
tmpPt_Ori=tmpPt(t);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%original code
tmpPt(t) = tmpPt(t)-tmpPx;
% inds_t = inds_t(find(inds_t~=x)); % inds_t = setdiff(inds_t,x);      
% tmpPy_t(:,t) = sum(Pyx(:,inds_t),2)./tmpPt(t);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

tmpPy_t(:,t)=(tmpPy_t(:,t)*tmpPt_Ori-Pyx(:,x))./tmpPt(t);
f = logical(abs(tmpPy_t(:,t)) < 0.0000000000001);
tmpPy_t(f,t) = 0;
return
